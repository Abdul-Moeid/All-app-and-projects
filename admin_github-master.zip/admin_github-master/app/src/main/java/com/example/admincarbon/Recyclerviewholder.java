package com.example.admincarbon;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class Recyclerviewholder extends RecyclerView.ViewHolder {
    public TextView ordkey,ordsts,ordmsg;
    public Button call;
    public Button show;
    public Recyclerviewholder(@NonNull View itemView) {
        super(itemView);
        ordkey=(TextView)itemView.findViewById(R.id.ordkey);
        ordsts=(TextView)itemView.findViewById(R.id.ordsts);
        ordmsg=(TextView)itemView.findViewById(R.id.ordmsg);
        call=(Button)itemView.findViewById(R.id.btn);
        show=(Button)itemView.findViewById(R.id.details);
    }
}
