package com.example.admincarbon;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.admincarbon.Model.cart;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.gson.Gson;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ordershow extends AppCompatActivity {
    private RecyclerView recyclerView;
    private LinearLayoutManager layoutManager;
    private ArrayList<recylerorderformat> arrayList;
    private FirebaseRecyclerOptions<recylerorderformat> options;
    private FirebaseRecyclerAdapter<recylerorderformat, Recyclerviewholder> adapter;
    private DatabaseReference databaseReference;
    public String pnum;

    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(ordershow.this,home.class));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ordershow);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        recyclerView = (RecyclerView) findViewById(R.id.recylerview);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        layoutManager.setReverseLayout(true);
        layoutManager.setStackFromEnd(true);
        recyclerView.setLayoutManager(layoutManager);
        arrayList = new ArrayList<recylerorderformat>();
        databaseReference = FirebaseDatabase.getInstance().getReference("order request");
        databaseReference.keepSynced(true);
        options = new FirebaseRecyclerOptions.Builder<recylerorderformat>().setQuery(databaseReference, recylerorderformat.class).build();
        adapter = new FirebaseRecyclerAdapter<recylerorderformat, Recyclerviewholder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull Recyclerviewholder recyclerviewholder, int i, @NonNull final recylerorderformat recylerorderformat) {
                String msg = "";
                List<cart> ord = new ArrayList<>();
                ord = recylerorderformat.getCart();
                pnum=recylerorderformat.getPhoneNumber().toString();
                for (cart h : ord) {
                    msg += h.getName().toString() + " " + h.getQuantity().toString() + ",";
                }
                if (msg.length() > 1) {
                    msg = msg.substring(0, msg.length() - 1);
                }
                recyclerviewholder.ordkey.setText("Order From " + recylerorderformat.getAdress());
                recyclerviewholder.ordsts.setText(msg);
                recyclerviewholder.ordmsg.setText("Total Price " + recylerorderformat.getTotal());
                final List<cart> finalOrd = ord;
                recyclerviewholder.show.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Gson gson = new Gson();
                        String jsonString = gson.toJson(finalOrd);
                        Intent intent = new Intent(ordershow.this, ShowDetails.class);
                        intent.putExtra("KEY",jsonString);
                        startActivity(intent);
                    }
                });
                recyclerviewholder.call.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        if(isPermissionGranted()){
                        call_action(recylerorderformat.getPhoneNumber().toString());}
                        else {
                            Toast.makeText(ordershow.this,"Permission Denied",Toast.LENGTH_SHORT).show();
                        }
                        //Toast.makeText(ordershow.this,recylerorderformat.getPhoneNumber(),Toast.LENGTH_SHORT).show();
                    }
                });

                //recyclerviewholder.itemView.setBackgroundColor(Color.GREEN);
                //recyclerviewholder.itemView.setPaddingRelative(5,5,5,5);
            }

            @NonNull
            @Override
            public Recyclerviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                return new Recyclerviewholder(LayoutInflater.from(ordershow.this).inflate(R.layout.recyclerrow,parent,false));
            }
        };

        recyclerView.setAdapter(adapter);
    }
    public void call_action(String phnum){
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel:" + phnum));
        startActivity(callIntent);
    }
    public  boolean isPermissionGranted() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(android.Manifest.permission.CALL_PHONE)
                    == PackageManager.PERMISSION_GRANTED) {
                return true;
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE}, 1);
                return false;
            }
        }
        else {
            return true;
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {

            case 1: {

                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    call_action(pnum);
                } else {
                }
                return;
            }

        }
    }

}
