package com.example.admincarbon;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatDialogFragment;

import com.example.admincarbon.ViewHolder.UpdateDialog;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class DeleteUpdateDialog extends AppCompatDialogFragment {
    String catagory, key,img,nm,pr;
    private StorageReference mStorageRef;

    public DeleteUpdateDialog (String catagory, String key,String img,String nm,String pr) {
        this.catagory = catagory;
        this.key = key;
        this.img=img;
        this.nm=nm;
        this.pr=pr;
    }
    final FirebaseDatabase database = FirebaseDatabase.getInstance();

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.layout_dialog, null);

        builder.setView(view)
                .setTitle("Delete or Update")
                .setNegativeButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        final DatabaseReference table_cat = database.getReference(catagory);
                        mStorageRef = FirebaseStorage.getInstance().getReference();
                        final StorageReference riversRef = mStorageRef.child("food/"+key+".jpg");
                        riversRef.delete();
                        table_cat.child(key).removeValue();

                    }
                })
                .setPositiveButton("Update", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        openDialog();
                    }
                });


        return builder.create();
    }

    private void openDialog() {
        UpdateDialog exampleDialog = new UpdateDialog(key,catagory,img,nm,pr);
        exampleDialog.show(getFragmentManager(),"update");
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        try {
            // listener = (ExampleDialogListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString() +
                    "must implement ExampleDialogListener");
        }
    }
}

