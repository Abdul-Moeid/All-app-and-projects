package com.example.admincarbon.ViewHolder;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.admincarbon.R;

public class CatagoryViewHolder extends RecyclerView.ViewHolder {
    public TextView name;
    public TextView price;
    public LinearLayout layout;
    public ImageView imageView;
    public TextView avl,dtsa;
    public CatagoryViewHolder(@NonNull View itemView) {
        super(itemView);
        name = (TextView)itemView.findViewById(R.id.foodname);
        price = (TextView) itemView.findViewById(R.id.price);
        imageView=(ImageView)itemView.findViewById(R.id.img);
        layout = itemView.findViewById(R.id.layout);
        avl=itemView.findViewById(R.id.avl);
        dtsa=itemView.findViewById(R.id.fooddtails);
    }
}