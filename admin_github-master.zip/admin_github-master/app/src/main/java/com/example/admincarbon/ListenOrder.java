package com.example.admincarbon;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.provider.ContactsContract;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;


import com.example.admincarbon.MainActivity;
import com.example.admincarbon.Model.cart;
import com.example.admincarbon.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ListenOrder extends Service implements ChildEventListener {
    FirebaseDatabase db;
    DatabaseReference OrderRequests;
    FirebaseAuth auth;
    FirebaseUser user;
    public static final String CHANNEL_ID1 = "ForegroundServiceChannel";
    public ListenOrder() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        auth=FirebaseAuth.getInstance();
        user=auth.getCurrentUser();
        db=FirebaseDatabase.getInstance();
        OrderRequests=db.getReference("order request");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground();
        OrderRequests.addChildEventListener(this);
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
        orderFormat a= (orderFormat) dataSnapshot.getValue(orderFormat.class);
        List<String> status=new ArrayList<String>();
        for (DataSnapshot dataValues : dataSnapshot.child("status").getChildren()){
            String st = (String) dataValues.getValue();
            status.add(st);
        }
        if(!status.contains(user.getUid()))
        {
            status.add(user.getUid());
//            a.setStatus("0");
//           OrderRequests.child(a.getKey()).setValue(a);
            OrderRequests.child(a.getKey()).child("status").setValue(status);
           showNotification(a);
        }


    }

    private void startForeground() {
        createNotificationChannel();
        Intent notificationIntent = new Intent(this, ordershow.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this,
               0, notificationIntent, 0);
        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID1)
                .setContentTitle("Carbon Restaurant")
                .setSmallIcon(R.drawable.carbon_logo)
                .setContentIntent(pendingIntent)
                .build();
        startForeground(1, notification);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(
                    CHANNEL_ID1,
                    "Foreground Service Channel",
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(serviceChannel);
        }
    }
    private void showNotification(orderFormat a) {
        String msg="";
        List<cart> ord=new ArrayList<>();
        ord= a.getCart();
        for(cart h:ord)
        {
            msg+=h.getName().toString()+" "+h.getQuantity().toString()+",";
        }
        if(msg.length()>1)
        {
            msg=msg.substring(0,msg.length()-1);
        }
        //Uri uri=Uri.parse("Order arrived");
        MediaPlayer mediaPlayer=MediaPlayer.create(this,R.raw.play);
        //mediaPlayer.start();
        //Uri uri=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        Intent notificationIntent = new Intent(this, ordershow.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this,
                0, notificationIntent, 0);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "Carbon Admin")
                .setSmallIcon(R.drawable.carbon_logo)
                .setContentTitle("New Order From "+a.getAdress())
                .setContentText(msg)
                .setContentIntent(pendingIntent)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            //CharSequence name = getString(R.string.channel_name);
            //String description = getString("eh");
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("Carbon Admin", "CARBON", importance);
            //channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);

// notificationId is a unique int for each notification that you must define
        mediaPlayer.start();
        notificationManager.notify(new Random().nextInt()+1, builder.build());



    }

    @Override
    public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {



    }

    @Override
    public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

    }

    @Override
    public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

    }

    @Override
    public void onCancelled(@NonNull DatabaseError databaseError) {

    }
}

