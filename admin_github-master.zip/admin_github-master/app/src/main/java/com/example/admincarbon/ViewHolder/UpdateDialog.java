package com.example.admincarbon.ViewHolder;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;

import com.example.admincarbon.Model.food;
import com.example.admincarbon.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

public class UpdateDialog extends AppCompatDialogFragment {
    private EditText editTextUsername;
    private EditText editTextPassword;
    TextView Name, Price,fooddetails;
    Button addimg;
    Spinner spinner;
    String key;
    String catagory;
    String im,nm,p;

    public UpdateDialog(String key, String catagory,String i,String nm,String p) {
        this.key = key;
        this.catagory = catagory;
        this.im=i;
        this.nm=nm;
        this.p=p;
    }

    ImageView img;
    public Uri selectedimage;
    public Uri dwnld;
    public FirebaseDatabase database;
    private StorageReference mStorageRef;
    DatabaseReference table_cat;
    public ProgressBar progressBar;
    public ProgressDialog progressDialog;
    public ToggleButton tg;
    public String avl;
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.update_dialog, null);
        progressDialog=new ProgressDialog(getContext());
        Name = view.findViewById(R.id.editText1);
        Price = view.findViewById(R.id.editText2);
        fooddetails=view.findViewById(R.id.fooddetails);
        addimg=view.findViewById(R.id.addimg);
        img=view.findViewById(R.id.img);
        tg=view.findViewById(R.id.tg);
        tg.setTextOn("Available");
        tg.setTextOff("Not available");
        tg.setChecked(false);
        avl="1";
        tg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(tg.isChecked())
                {
                    avl="1";
                }
                else{
                    avl="0";
                }
            }
        });
        Name.setText(nm);
        Price.setText(p);
        Picasso.get().load(im).into(img);
        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        mStorageRef = FirebaseStorage.getInstance().getReference();
        table_cat = database.getReference(catagory);
        final StorageReference riversRef = mStorageRef.child("food/"+key+".jpg");

        builder.setView(view)
                .setTitle("Update")
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                })
                .setPositiveButton("Update", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if(selectedimage!=null) {
                            mStorageRef = FirebaseStorage.getInstance().getReference();
                            final StorageReference riversRef = mStorageRef.child("food/" + key + ".jpg");
                            progressDialog.setTitle("Uploading...");
                            progressDialog.show();
                            riversRef.putFile(selectedimage)
                                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                        @Override
                                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                            // Get a URL to the uploaded content
                                            riversRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                                @Override
                                                public void onSuccess(Uri uri) {

                                                    if (uri != null) {
                                                        dwnld = uri;
                                                    }
                                                    food item = new food(Name.getText().toString(), Price.getText().toString(), Name.getText().toString().toLowerCase(), dwnld.toString(), key.toString(),avl,fooddetails.getText().toString());
                                                    table_cat.child(key.toString()).setValue(item);
                                                    progressDialog.dismiss();
                                                    //progressDialog.dismiss();
                                                    //                                             Toast.makeText(getContext(), "Item is added successfully!", Toast.LENGTH_SHORT).show();
                                                }
                                            });
                                        }
                                    })
                                    .addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception exception) {
                                            // Handle unsuccessful uploads
                                            // ...progressDialog.dismiss();
                                            progressDialog.dismiss();
                                        }
                                    })
                                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                                        @Override
                                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                                            double progress = (100 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                                            progressDialog.setMessage("Uploaded " + (int) progress + "%");
                                        }
                                    });
                        }
                        else {
                            food it=new food(Name.getText().toString(),Price.getText().toString(),Name.getText().toString().toLowerCase(),im,key,avl,fooddetails.getText().toString());
                            table_cat.child(key).setValue(it);


                        }

                    }
                });
        addimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent pick=new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(pick,1);

            }
        });


        return builder.create();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        try {
            //listener = (ExampleDialogListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString() +
                    "must implement ExampleDialogListener");
        }
    }




    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==1)
        {
            selectedimage=data.getData();
            img.setImageURI(selectedimage);


        }
    }
}