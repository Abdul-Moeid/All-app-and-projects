package com.example.admincarbon.ui.send;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.admincarbon.R;
import com.example.admincarbon.home;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class SendFragment extends Fragment {


    FirebaseDatabase database;
    DatabaseReference databaseReference;
    EditText content;
    Button post;
    String p="";
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_send, container, false);
        content=(EditText)root.findViewById(R.id.contnt);
        post=(Button)root.findViewById(R.id.post);
        database=FirebaseDatabase.getInstance();
        databaseReference=database.getReference("offer post");
        post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(content.getText().length()!=0){
                p="****"+content.getText()+"****";}
                databaseReference.child("1").setValue(p);
                Toast.makeText(getContext(),"Offer has been posted",Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(getContext(), home.class);
                startActivity(intent);

            }
        });

        return root;
    }
}