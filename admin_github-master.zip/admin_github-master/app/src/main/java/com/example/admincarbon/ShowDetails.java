package com.example.admincarbon;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.hardware.camera2.TotalCaptureResult;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.example.admincarbon.Model.cart;
import com.example.admincarbon.ViewHolder.Details_Show_Adapter;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class ShowDetails extends AppCompatActivity {
    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    List<cart> Cart=new ArrayList<>();
    Details_Show_Adapter adapter;
    TextView total;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_details);
        Bundle bundle = getIntent().getExtras();
        String jsonString = bundle.getString("KEY");

        Gson gson = new Gson();
        Type listOfdoctorType = new TypeToken<List<cart>>() {}.getType();
        total=(TextView)findViewById(R.id.total);
        Cart= gson.fromJson(jsonString,listOfdoctorType );
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        ActionBar actionBar=getSupportActionBar();
        actionBar.setTitle("Cart");
        recyclerView=(RecyclerView)findViewById(R.id.listcart);
        recyclerView.setHasFixedSize(true);
        layoutManager=new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        adapter=new Details_Show_Adapter(Cart,this);
        recyclerView.setAdapter(adapter);
        String[] g=new String[2];
        int t=0;
        for(cart a:Cart) {
            g = a.getPrice().split("T");
            t += (Integer.parseInt(g[0]))*(Integer.parseInt(a.getQuantity()));
        }
        total.setText(String.valueOf(t)+"Tk");
    }
}
