package com.example.admincarbon.ViewHolder;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.admincarbon.Model.cart;
import com.example.admincarbon.R;
import com.example.admincarbon.ShowDetails;

import java.util.ArrayList;
import java.util.List;

class Details_Show_ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
    public TextView item_name,item_price,item_count;

    public Details_Show_ViewHolder(@NonNull View itemView) {
        super(itemView);
        item_name=(TextView)itemView.findViewById(R.id.item_name);
        item_price=(TextView)itemView.findViewById(R.id.item_price);
        item_count=(TextView)itemView.findViewById(R.id.numbtn);
    }

    @Override
    public void onClick(View v) {

    }


}
public class Details_Show_Adapter extends RecyclerView.Adapter<Details_Show_ViewHolder> {
    private List<cart> list=new ArrayList<>();
    private ShowDetails context;

    public Details_Show_Adapter(List<cart> list, ShowDetails context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public Details_Show_ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(context);
        View itemView=inflater.inflate(R.layout.detailsrow,parent,false);
        return new Details_Show_ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull Details_Show_ViewHolder holder, final int position) {
        holder.item_name.setText(list.get(position).getName());
        holder.item_price.setText(list.get(position).getPrice());
        holder.item_count.setText(list.get(position).getQuantity()+"x");

    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}
