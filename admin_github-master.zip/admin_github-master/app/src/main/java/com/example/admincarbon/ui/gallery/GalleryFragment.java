package com.example.admincarbon.ui.gallery;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.KeyboardShortcutGroup;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.admincarbon.Model.food;
import com.example.admincarbon.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import static com.firebase.ui.auth.AuthUI.getApplicationContext;

public class GalleryFragment extends Fragment implements AdapterView.OnItemClickListener, AdapterView.OnItemSelectedListener {

    TextView Name, Price,fooddetails, allitem;
    Button add,addimg;
    Spinner spinner;
    String catagory;
    ImageView img;
    public Uri selectedimage;
    public Uri dwnld;
    public String id;
    private StorageReference mStorageRef;
    DatabaseReference table_cat, newtable;
    public ProgressBar progressBar;
    public ProgressDialog progressDialog;
    private static final String[] cat = {"Bengali", "Chinese", "Indian","Drinks","Dessert","Fast food","Setmenu","Kebab"};


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_gallery, container, false);

        // spinner for drop down menu

        spinner = root.findViewById(R.id.spinner);
        ArrayAdapter<String>adapter = new ArrayAdapter<String>(getActivity(),
                android.R.layout.simple_spinner_item,cat);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);

        ///

        progressDialog=new ProgressDialog(getContext());
        add = root.findViewById(R.id.button2);
        Name = root.findViewById(R.id.editText1);
        Price = root.findViewById(R.id.editText2);
        addimg=root.findViewById(R.id.addimg);
        allitem = root.findViewById(R.id.itmno);
        fooddetails=root.findViewById(R.id.fooddetails);
        img=root.findViewById(R.id.img);
        mStorageRef = FirebaseStorage.getInstance().getReference();
        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        newtable = database.getReference("All");
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(selectedimage == null)
                {
                    selectedimage =Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE +
                            "://" + getResources().getResourcePackageName(R.drawable.comingsoon)
                            + '/' + getResources().getResourceTypeName(R.drawable.comingsoon)
                            + '/' + getResources().getResourceEntryName(R.drawable.comingsoon) );
                }
                id=String.valueOf(System.currentTimeMillis());
                table_cat = database.getReference(catagory);
                final StorageReference riversRef = mStorageRef.child("food/"+id+".jpg");
                progressDialog.setTitle("Uploading...");
                progressDialog.show();
                if(selectedimage == null)
                {
                    selectedimage =Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE +
                            "://" + getResources().getResourcePackageName(R.drawable.comingsoon)
                            + '/' + getResources().getResourceTypeName(R.drawable.comingsoon)
                            + '/' + getResources().getResourceEntryName(R.drawable.comingsoon) );
                }
                riversRef.putFile(selectedimage)
                        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                // Get a URL to the uploaded content
                                riversRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri uri) {
                                        dwnld=uri;
                                        String pr= allitem.getText().toString()+". "+Name.getText().toString();
                                        food item1=new food(Name.getText().toString(),Price.getText().toString()+"Tk",Name.getText().toString().toLowerCase(),dwnld.toString(),id.toString(),"1",fooddetails.getText().toString());
                                        food  item = new food(pr,Price.getText().toString()+"Tk",pr.toLowerCase(),dwnld.toString(),allitem.getText().toString(),"1",fooddetails.getText().toString());
                                        table_cat.child(id.toString()).setValue(item1);
                                        newtable.child(allitem.getText().toString()).setValue(item);
                                        progressDialog.dismiss();
                                        Toast.makeText(getActivity(), "Item is added successfully!", Toast.LENGTH_SHORT).show();
                                    }
                                });
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception exception) {
                                // Handle unsuccessful uploads
                                // ...progressDialog.dismiss();
                                progressDialog.dismiss();
                            }
                        })
                        .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                                double progress=(100*taskSnapshot.getBytesTransferred()/taskSnapshot.getTotalByteCount());
                                progressDialog.setMessage("Uploaded "+(int)progress+"%");
                            }
                        })
                ;



            }
        });
        addimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent pick=new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(pick,1);

            }
        });

        return root;
    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        catagory = cat[position];
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==1)
        {
            selectedimage=data.getData();
            img.setImageURI(selectedimage);


        }
    }
}