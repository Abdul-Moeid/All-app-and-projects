package com.example.staffcarbon.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;

import androidx.annotation.Nullable;

import com.example.staffcarbon.FeedReaderContract;
import com.example.staffcarbon.Model.cart;

import java.util.ArrayList;
import java.util.List;

public class Database extends SQLiteOpenHelper {
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "Cart.db";

    public Database(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
                "create table cart1 " +
                        "(id integer primary key,Catagory text,Name text,Price text,Quantity text)"
        );
        db.execSQL(
                "create table cart2 " +
                        "(id integer primary key,Catagory text,Name text,Price text,Quantity text)"
        );
        db.execSQL(
                "create table cart3 " +
                        "(id integer primary key,Catagory text,Name text,Price text,Quantity text)"
        );
        db.execSQL(
                "create table cart4 " +
                        "(id integer primary key,Catagory text,Name text,Price text,Quantity text)"
        );
        db.execSQL(
                "create table cart5 " +
                        "(id integer primary key,Catagory text,Name text,Price text,Quantity text)"
        );
        db.execSQL(
                "create table cart6 " +
                        "(id integer primary key,Catagory text,Name text,Price text,Quantity text)"
        );
        db.execSQL(
                "create table cart7 " +
                        "(id integer primary key,Catagory text,Name text,Price text,Quantity text)"
        );
        db.execSQL(
                "create table cart8 " +
                        "(id integer primary key,Catagory text,Name text,Price text,Quantity text)"
        );
        db.execSQL(
                "create table cart9 " +
                        "(id integer primary key,Catagory text,Name text,Price text,Quantity text)"
        );
        db.execSQL(
                "create table cart10 " +
                        "(id integer primary key,Catagory text,Name text,Price text,Quantity text)"
        );
        db.execSQL(
                "create table cart11 " +
                        "(id integer primary key,Catagory text,Name text,Price text,Quantity text)"
        );
        db.execSQL(
                "create table cart12 " +
                        "(id integer primary key,Catagory text,Name text,Price text,Quantity text)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS cart1");
        db.execSQL("DROP TABLE IF EXISTS cart2");
        db.execSQL("DROP TABLE IF EXISTS cart3");
        db.execSQL("DROP TABLE IF EXISTS cart4");
        db.execSQL("DROP TABLE IF EXISTS cart5");
        db.execSQL("DROP TABLE IF EXISTS cart6");
        db.execSQL("DROP TABLE IF EXISTS cart7");
        db.execSQL("DROP TABLE IF EXISTS cart8");
        db.execSQL("DROP TABLE IF EXISTS cart9");
        db.execSQL("DROP TABLE IF EXISTS cart10");
        db.execSQL("DROP TABLE IF EXISTS cart11");
        db.execSQL("DROP TABLE IF EXISTS cart12");

        onCreate(db);
    }

    public List<cart> getCarts(String tbn) {
        SQLiteDatabase db = getReadableDatabase();
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

        String[] select = {"id","Catagory", "Name", "Price", "Quantity"};
        String table = "cart"+tbn;
        qb.setTables(table);
        Cursor c = qb.query(db, select, null, null, null, null, null);
        final List<cart> result = new ArrayList<>();
        if (c.moveToFirst()) {
            do {
                result.add(new cart(c.getInt(c.getColumnIndex("id")),
                        c.getString(c.getColumnIndex("Catagory")),
                        c.getString(c.getColumnIndex("Name")),
                        c.getString(c.getColumnIndex("Price")),
                        c.getString(c.getColumnIndex("Quantity"))
                ));
            } while (c.moveToNext());

        }
        return result;
    }

    public int numberOfRows(String tbn){
        SQLiteDatabase db = this.getReadableDatabase();
        int numRows = (int) DatabaseUtils.queryNumEntries(db, "cart"+tbn);
        return numRows;
    }

    public void addCart(cart Cart,String tbn)
    {
        SQLiteDatabase db=getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("Catagory",Cart.getCatagory());
        contentValues.put("Name",Cart.getName());
        contentValues.put("Price",Cart.getPrice());
        contentValues.put("Quantity",Cart.getQuantity());
        long newRowId = db.insert("cart"+tbn, null, contentValues);
//        String query=String.format("INSERT INTO cart(Catagory,Name,Price,Quantity) VALUES('%s','%s','%s','%s','%s');",
//                Cart.getCatagory(),
//                Cart.getName(),
//                Cart.getPrice(),
//                Cart.getQuantity());
//        db.execSQL(query);
    }

    public void updateCart(cart Cart,String tbn)
    {

        SQLiteDatabase db=getWritableDatabase();
        String query=String.format("UPDATE cart"+tbn+" SET Quantity=%s WHERE id=%s",Cart.getQuantity(),Cart.getId());
        db.execSQL(query);


    }
    public void cleanCart(String tbn)
    {
        SQLiteDatabase db=getWritableDatabase();
        String query=String.format("DELETE FROM cart"+tbn);
        db.execSQL(query);
    }
    public void deleteCart(String tbn,String pos)
    {
        SQLiteDatabase db=getWritableDatabase();
        String query=String.format("DELETE FROM cart"+tbn+" where id="+pos);
        db.execSQL(query);
    }
}
