package com.example.staffcarbon;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    CardView t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        t1=(CardView)findViewById(R.id.tb1);
        t2=(CardView)findViewById(R.id.tb2);
        t3=(CardView)findViewById(R.id.tb3);
        t4=(CardView)findViewById(R.id.tb4);
        t5=(CardView)findViewById(R.id.tb5);
        t6=(CardView)findViewById(R.id.tb6);
        t7=(CardView)findViewById(R.id.tb7);
        t8=(CardView)findViewById(R.id.tb8);
        t9=(CardView)findViewById(R.id.tb9);
        t10=(CardView)findViewById(R.id.tb10);
        t11=(CardView)findViewById(R.id.tb11);
        t12=(CardView)findViewById(R.id.tb12);
        t1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,Tableorder.class);
                intent.putExtra("key","1");
                startActivity(intent);

            }
        });
        t2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,Tableorder.class);
                intent.putExtra("key","2");
                startActivity(intent);

            }
        });
        t3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,Tableorder.class);
                intent.putExtra("key","3");
                startActivity(intent);

            }
        });
        t4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,Tableorder.class);
                intent.putExtra("key","4");
                startActivity(intent);

            }
        });
        t5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,Tableorder.class);
                intent.putExtra("key","5");
                startActivity(intent);

            }
        });
        t6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,Tableorder.class);
                intent.putExtra("key","6");
                startActivity(intent);

            }
        });
        t7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,Tableorder.class);
                intent.putExtra("key","7");
                startActivity(intent);

            }
        });
        t8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,Tableorder.class);
                intent.putExtra("key","8");
                startActivity(intent);

            }
        });
        t9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,Tableorder.class);
                intent.putExtra("key","9");
                startActivity(intent);

            }
        });
        t10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,Tableorder.class);
                intent.putExtra("key","10");
                startActivity(intent);

            }
        });
        t11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,Tableorder.class);
                intent.putExtra("key","11");
                startActivity(intent);

            }
        });
        t12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,Tableorder.class);
                intent.putExtra("key","12");
                startActivity(intent);

            }
        });
    }


    }

