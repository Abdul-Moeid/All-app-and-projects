package com.example.staffcarbon.Model;

public class food {
    private String Name;
    private  String Price;
    private  String Image;
    private String Status;
    private String Fooddtails;
    private  String Key;
    public food() {
    }

    public food(String name, String price,String image,String status,String fooddtails,String key) {
        Name = name;
        Price = price;
        Image= image;
        Status=status;
        Fooddtails=fooddtails;
        Key=key;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getPrice() {
        return Price;
    }

    public void setPrice(String price) {
        Price = price;
    }

    public String getImage() {
        return Image;
    }

    public void setImage(String image) {
        Image = image;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public String getFooddtails() {
        return Fooddtails;
    }

    public void setFooddtails(String fooddtails) {
        Fooddtails = fooddtails;
    }

    public String getKey() {
        return Key;
    }

    public void setKey(String key) {
        Key = key;
    }
}
