package com.example.staffcarbon;

import android.provider.BaseColumns;

public final class FeedReaderContract {
    private FeedReaderContract() {}

    /* Inner class that defines the table contents */
    public static class FeedEntry implements BaseColumns {
        public static final String TABLE_NAME1 = "cart1";
        public static final String TABLE_NAME2= "cart2";
        public static final String TABLE_NAME3 = "cart3";
        public static final String TABLE_NAME4 = "cart4";
        public static final String TABLE_NAME5= "cart5";
        public static final String TABLE_NAME6= "cart6";
        public static final String TABLE_NAME7= "cart7";
        public static final String TABLE_NAME8= "cart8";
        public static final String TABLE_NAME9= "cart9";
        public static final String TABLE_NAME10= "cart10";
        public static final String TABLE_NAME11= "cart11";
        public static final String TABLE_NAME12= "cart12";
        public static final String COLUMN_NAME_TITLE = "Catagory";
        public static final String COLUMN_NAME_TITLE1 = "Name";
        public static final String COLUMN_NAME_TITLE2 = "Price";
        public static final String COLUMN_NAME_TITLE3 = "Quantity";
    }
}
