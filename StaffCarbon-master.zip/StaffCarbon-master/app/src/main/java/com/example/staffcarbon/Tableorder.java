package com.example.staffcarbon;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.staffcarbon.Database.Database;
import com.example.staffcarbon.Model.cart;
import com.example.staffcarbon.Model.food;
import com.example.staffcarbon.ViewHolder.CartAdapter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.zip.Inflater;

public class Tableorder extends AppCompatActivity {
    public static String tbn;
    public static RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    FirebaseDatabase database;
    DatabaseReference databaseReference;
    public static TextView Total;
    Button Order;
    List<cart> Cart=new ArrayList<>();
    CartAdapter adapter;
    String Adress;
    String total=null;
    private FirebaseUser user;
    private FirebaseAuth auth;
    int o=0;
    View view;
    FloatingActionButton fab;
    public static Database mydb;
    EditText food_no,price,food_name,qunatity;
    LayoutInflater inflater;
    AlertDialog.Builder builder;
    ArrayList<food> foods;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tableorder);
        final Bundle bundle = getIntent().getExtras();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        if(bundle!=null){
            String val = bundle.getString("key");
            //Log.d("tag",val);
            tbn = val;
            getSupportActionBar().setTitle("Table no "+tbn+" Cart");
        }
        foods=new ArrayList<food>(1000);
        database=FirebaseDatabase.getInstance();
        databaseReference=database.getReference("All");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                food f=null;
                for (DataSnapshot dataSnapshot1:dataSnapshot.getChildren())
                {
                    f=dataSnapshot1.getValue(food.class);
                    foods.add(f);
                }

            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        inflater = this.getLayoutInflater();
        recyclerView=(RecyclerView)findViewById(R.id.listcart);
        recyclerView.setHasFixedSize(true);
        layoutManager=new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        Total=(TextView)findViewById(R.id.total);
        Order=(Button) findViewById(R.id.order);
        mydb=new Database(this);
        view= inflater.inflate(R.layout.layout_dialog,null,false);
        food_no=(EditText) view.findViewById(R.id.editText1);
        price=(EditText)view.findViewById(R.id.editText2);
        food_name=(EditText)view.findViewById(R.id.editText3);
        qunatity=(EditText)view.findViewById(R.id.editText4);
        food_no.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(final CharSequence s, int start, int before, int count) {

                    for (int i = 0; i < foods.size(); i++)

                            if (String.valueOf(i + 1).equals(food_no.getText().toString())) {
                                //Toast.makeText(Tableorder.this, foods.get(i).getKey(), Toast.LENGTH_SHORT).show();
                                food_name.setText(foods.get(i).getName());
                                price.setText(foods.get(i).getPrice().replaceAll("Tk","").trim());
                                qunatity.setText("1");
                            }


                    }




            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        fab=(FloatingActionButton)findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Toast.makeText(Tableorder.this,"hello",Toast.LENGTH_SHORT).show();
//                mydb.addCart(new cart(
//////                        "All",
//////                        "Am",
//////                        "10Tk",
//////                        "1"
//////                ),tbn);
                if (view.getParent()!=null)
                {
                    ((ViewGroup)view.getParent()).removeView(view);
                }
                builder = new AlertDialog.Builder(Tableorder.this);
                builder.setTitle("One more step");
                builder.setIcon(R.drawable.ic_shopping_cart_black_24dp);
                builder.setMessage("Enter food details");
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.MATCH_PARENT
                );
                builder.setView(view);
                builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
//                        mydb.addCart(new cart(
//                        "All",
//                        food_name.getText().toString().trim(),
//                        price.getText().toString().trim(),
//                        "1"
//                ),tbn);
//                        loadCart();
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
//                builder.create();
//                builder.show();
                final AlertDialog dialog=builder.create();
                dialog.show();
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(TextUtils.isEmpty(food_name.getText()))
                        {
                            food_name.setError("food name can't be null");
                            return;
                        }
                        if(TextUtils.isEmpty(price.getText()))
                        {
                            price.setError("price can't be null");
                            return;
                        }
                        if(TextUtils.isEmpty(qunatity.getText()))
                        {
                            qunatity.setError("quantity can't be null");
                            return;
                        }
                        mydb.addCart(new cart(
                        "All",
                        food_name.getText().toString().trim(),
                        price.getText().toString().trim(),
                        "1"
                ),tbn);
                        loadCart();
                        dialog.dismiss();

                    }
                });
                //mydb.cleanCart(tbn);

            }
        });
        loadCart();
    }
    public void loadCart() {
        String[] g=new String[2];
        Cart=new Database(this).getCarts(tbn);
        adapter=new CartAdapter(Cart,this);
        recyclerView.setAdapter(adapter);
        int t=0;
        for(cart a:Cart) {
            g = a.getPrice().split("T");
            t += (Integer.parseInt(g[0]))*(Integer.parseInt(a.getQuantity()));
        }
        Total.setText(String.valueOf(t)+"Tk");
    }

}
