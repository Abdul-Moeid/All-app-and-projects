package com.example.staffcarbon.ViewHolder;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.cepheuen.elegantnumberbutton.view.ElegantNumberButton;
import com.example.staffcarbon.Database.Database;
import com.example.staffcarbon.MainActivity;
import com.example.staffcarbon.Model.cart;
import com.example.staffcarbon.R;
import com.example.staffcarbon.Tableorder;

import java.util.ArrayList;
import java.util.List;

class CartViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
    public TextView item_name,item_price;
    public ElegantNumberButton ebtn;
    public ImageView delet;

    @Override
    public void onClick(View v) {

    }

    public CartViewHolder(@NonNull View itemView) {
        super(itemView);
        item_name=(TextView)itemView.findViewById(R.id.item_name);
        item_price=(TextView)itemView.findViewById(R.id.item_price);
        ebtn=(ElegantNumberButton)itemView.findViewById(R.id.numbtn);
        delet=(ImageView)itemView.findViewById(R.id.delete);
    }
}

public class CartAdapter extends RecyclerView.Adapter<CartViewHolder> {
    private List<cart> list=new ArrayList<>();
    private Tableorder context;

    public CartAdapter(List<cart> list, Tableorder context) {
        this.list = list;
        this.context = context;
    }


    @NonNull
    @Override
    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(context);
        View itemView=inflater.inflate(R.layout.table_cart_row,parent,false);
        return new CartViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull CartViewHolder holder, final int position) {
        holder.item_name.setText(list.get(position).getName());
        holder.item_price.setText(list.get(position).getPrice());
        holder.ebtn.setNumber(list.get(position).getQuantity());
        holder.delet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Database(context).deleteCart(Tableorder.tbn,String.valueOf(position+1));
                List<cart> Cart=new Database(context).getCarts(Tableorder.tbn);
                Tableorder.recyclerView.setAdapter(new CartAdapter(Cart,context));
                String[] g=new String[2];
                int t=0;
                for(cart a:Cart) {
                    g = a.getPrice().split("T");
                    t += (Integer.parseInt(g[0]))*(Integer.parseInt(a.getQuantity()));
                }
                Tableorder.Total.setText(String.valueOf(t)+"Tk");
            }
        });
        holder.ebtn.setOnValueChangeListener(new ElegantNumberButton.OnValueChangeListener() {
            @Override
            public void onValueChange(ElegantNumberButton view, int oldValue, int newValue) {
                cart c=list.get(position);
                c.setQuantity(String.valueOf(newValue));
                new Database(context).updateCart(c,Tableorder.tbn);
                String[] g=new String[2];
                List<cart>abc=new Database(context).getCarts(Tableorder.tbn);
                int t=0;
                for(cart a:abc) {
                    g = a.getPrice().split("T");
                    t += (Integer.parseInt(g[0]))*(Integer.parseInt(a.getQuantity()));
                }
                context.Total.setText(String.valueOf(t)+"Tk");
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}
